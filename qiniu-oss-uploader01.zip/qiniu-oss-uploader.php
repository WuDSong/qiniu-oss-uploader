<?php
/*
Plugin Name: 七牛云OSS图片上传插件
Plugin URI: 
Description: WordPress上传图片自动同步到七牛云OSS，支持配置是否本地保存原图
Version: 1.0
Author: wudongsong
Author URI: 
License: MIT
*/

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// 引入七牛SDK自动加载文件
require_once plugin_dir_path(__FILE__) . 'includes/qiniu-sdk/autoload.php';

// 引入设置页面逻辑
require_once plugin_dir_path(__FILE__) . 'includes/settings.php';

/**
 * 核心上传逻辑：拦截WordPress文件上传，同步到七牛云
 * @param array $upload 上传结果数组
 * @param string $context 上传上下文
 * @return array
 */
function qiniu_oss_upload_file($upload, $context) {
    // 仅处理图片类型
    $allowed_mimes = array(
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp',
        'image/svg+xml'
    );
    if (!in_array($upload['type'], $allowed_mimes)) {
        return $upload;
    }

    // 获取七牛配置
    $access_key = get_option('qiniu_oss_access_key');
    $secret_key = get_option('qiniu_oss_secret_key');
    $bucket = get_option('qiniu_oss_bucket');
    $zone = get_option('qiniu_oss_zone');
    $domain = get_option('qiniu_oss_domain');
    $save_local = get_option('qiniu_oss_save_local', 'yes');

    // 配置验证
    if (empty($access_key) || empty($secret_key) || empty($bucket) || empty($zone) || empty($domain)) {
        return $upload;
    }

    try {
        // 1. 初始化七牛鉴权和配置
        $auth = new \Qiniu\Auth($access_key, $secret_key);
        $token = $auth->uploadToken($bucket);
        
        // 配置七牛区域
        $config = new \Qiniu\Config();
        switch ($zone) {
            case 'z0': $config->setZone(new \Qiniu\Zone\Zone_z0()); break; // 华东
            case 'z1': $config->setZone(new \Qiniu\Zone\Zone_z1()); break; // 华北
            case 'z2': $config->setZone(new \Qiniu\Zone\Zone_z2()); break; // 华南
            case 'na0': $config->setZone(new \Qiniu\Zone\Zone_na0()); break; // 北美
            case 'as0': $config->setZone(new \Qiniu\Zone\Zone_as0()); break; // 东南亚
        }

        // 2. 上传文件到七牛
        $uploadMgr = new \Qiniu\Storage\UploadManager($config);
        $file_path = $upload['file'];
        // 生成唯一文件名（避免重复）
        $file_name = wp_generate_uuid4() . '-' . basename($file_path);
        list($ret, $err) = $uploadMgr->putFile($token, $file_name, $file_path);

        if ($err !== null) {
            throw new Exception($err->message());
        }

        // 3. 处理七牛返回结果
        $qiniu_url = rtrim($domain, '/') . '/' . $ret['key'];
        
        // 4. 替换WordPress上传结果的URL为七牛URL
        $upload['url'] = $qiniu_url;
        $upload['path'] = $qiniu_url; // 覆盖本地路径（可选）

        // 5. 如果选择不保存本地，删除服务器原图
        if ($save_local !== 'yes' && file_exists($file_path)) {
            unlink($file_path);
        }

    } catch (Exception $e) {
        // 上传失败则保留本地上传结果
        error_log('七牛云上传失败：' . $e->getMessage());
    }

    return $upload;
}
add_filter('wp_handle_upload', 'qiniu_oss_upload_file', 10, 2);

/**
 * 修复媒体库中图片的URL显示
 * @param string $url 媒体文件URL
 * @param int $attachment_id 附件ID
 * @return string
 */
function qiniu_oss_fix_media_url($url, $attachment_id) {
    $attachment = get_post($attachment_id);
    if ($attachment->post_mime_type && str_starts_with($attachment->post_mime_type, 'image/')) {
        $qiniu_domain = get_option('qiniu_oss_domain');
        if (!empty($qiniu_domain) && str_contains($url, ABSPATH)) {
            // 替换本地URL为七牛URL（如果上传成功）
            $meta = wp_get_attachment_metadata($attachment_id);
            if (!empty($meta['qiniu_url'])) {
                return $meta['qiniu_url'];
            }
        }
    }
    return $url;
}
add_filter('wp_get_attachment_url', 'qiniu_oss_fix_media_url', 10, 2);

/**
 * 保存附件元数据时记录七牛URL
 * @param array $metadata 附件元数据
 * @param int $attachment_id 附件ID
 * @return array
 */
function qiniu_oss_save_attachment_meta($metadata, $attachment_id) {
    $file = get_attached_file($attachment_id);
    $qiniu_domain = get_option('qiniu_oss_domain');
    if (!empty($qiniu_domain) && str_starts_with($file, $qiniu_domain)) {
        $metadata['qiniu_url'] = $file;
    }
    return $metadata;
}
add_filter('wp_generate_attachment_metadata', 'qiniu_oss_save_attachment_meta', 10, 2);